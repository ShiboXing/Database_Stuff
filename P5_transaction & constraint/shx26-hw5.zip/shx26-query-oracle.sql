--Shibo Xing
--shx26

/*
select * from coverage;
select * from forest;
select * from intersection;
select * from report;
select * from road;
select * from sensor;
select * from state;
select * from worker;
*/

--3a
select S.sensor_id from sensor S join report R
on S.sensor_id = R.sensor_id
group by S.sensor_id
order by count(R.sensor_id) desc
fetch first 3 rows only;

--3b
select S.sensor_id from sensor S join report R
on S.sensor_id = R.sensor_id
group by S.sensor_id
order by count(R.sensor_id) desc
offset 3 row
fetch next 2 rows only;

--4a
create view DUTIES (D_name,D_cnt)
as select name,count(sensor_id) from sensor join WORKER on SENSOR.MAINTAINER = WORKER.SSN
group by name;



--4b
create materialized view DUTIES_MV
as select * from DUTIES;


--4c
create or replace view FOREST_SENSOR (fs_forest_no,fs_name,fs_sensor_id)
as select forest_no,f.name,s.sensor_id from forest f, sensor s
where s.x between f.mbr_xmin and f.mbr_xmax and s.y between f.mbr_ymin and f.mbr_ymax;


--question 5: after running the extra data sql
begin
    DBMS_MVIEW.REFRESH('DUTIES_MV');
end;

--5a
select D_name from DUTIES
where D_cnt in (select max(D_cnt) from DUTIES);


--5b
select distinct fs_name from FOREST_SENSOR
where fs_sensor_id not in (select sensor_id
    from sensor s natural join report f
    where f.report_time between to_timestamp('10-AUG-2019 00:00:00', 'DD-MON-YYYY HH24:MI:SS')
    and to_timestamp('11-AUG-2019 00:00:00', 'DD-MON-YYYY HH24:MI:SS'));

--5a_mv
select D_name from DUTIES_MV
where D_cnt in (select max(D_cnt) from DUTIES_MV);

--5d
    --5a (using view): 3 ms
    --5a_mv(using materialized view): 0 ms

--clean up
drop view DUTIES cascade constraints;
drop materialized view DUTIES_MV;




